# Agenda Cultural

Monografia para uma plataforma de agregamento de eventos culturais.
Desenvolvido como Trabalho de Conclusão de Curso, para a FC - UNESP Bauru, no curso de Bacharelado de Sistemas de Informação.

---
